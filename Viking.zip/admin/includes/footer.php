  <!-- JAVASCRIPT -->
  <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <script src="assets/libs/apexcharts/apexcharts.min.js"></script>

    <script src="assets/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <script src="assets/libs/jsvectormap/maps/world-merc.js"></script>

    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <script src="assets/js/pages/dashboard-ecommerce.init.js"></script>
  <!-- prismjs plugin -->
  <script src="assets/libs/prismjs/prism.js"></script>

<!-- gridjs js -->
<script src="assets/libs/gridjs/gridjs.umd.js"></script>
<!-- gridjs init -->
<script src="assets/js/pages/gridjs.init.js"></script>
    <script src="assets/js/app.js"></script>
    <!-- jQuery (Required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {
        $('#myTable').DataTable();
    });
</script>
</body>



</html>